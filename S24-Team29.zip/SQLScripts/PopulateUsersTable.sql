-- Active: 1708026071767@@team29-database.cobd8enwsupz.us-east-1.rds.amazonaws.com@3306@team29database
INSERT INTO Users (user_id, name, email, phone_number, usertype, points, sponsor, accepted) VALUES
('adjames', 'Austin Jameson', 'adjames@clemson.edu', '+14103028231', 'sponsor', 200, 3, 'Pending'),
('AdminTest', 'Test Admin', 'joshgardner1747@gmail.com', '+14048598001', 'admin', 0, 2, 'Pending'),
('ayoon', 'Andrew Yoon', 'ayoon6345@gmail.com', '+18649061525', 'driver', 33, 0, 'Declined'),
('DriverTest', 'Test Driver', 'joshgardner1747@gmail.com', '+14048598001', 'driver', 10001, 0, 'Pending'),
('joelm', 'Joel', 'upstatespam@gmail.com', '+18643869091', 'driver', 0, 1, 'Pending'),
('jtest', 'Josh Gardner', 'joshgardner1747@gmail.com', '+14048598001', 'driver', 100, 1, 'Pending'),
('SponsorTest', 'Test Sponsor', 'joshgardner1747@gmail.com', '+14048598001', 'sponsor', 0, 1, 'Pending'),
('testadj', 'Austin Jameson', 'xxadjbossxx@gmail.com', '+14103028231', 'driver', 433, 2, 'Pending');
