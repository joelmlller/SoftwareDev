-- Active: 1708026071767@@team29-database.cobd8enwsupz.us-east-1.rds.amazonaws.com@3306@team29database
INSERT INTO Applications (sponsor_id, user_id, name, accepted) VALUES
(2, 'testadj', 'Justin', 'Pending'),
(3, 'testadj', 'Justin', 'Accepted'),
(4, 'jtest', 'Bob', 'Pending'),
(5, 'jtest', 'Ricky', 'Accepted'),
(6, 'testadj', 'Austin Jameson', 'Pending');
