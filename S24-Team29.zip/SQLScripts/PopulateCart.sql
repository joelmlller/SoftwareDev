-- Active: 1708026071767@@team29-database.cobd8enwsupz.us-east-1.rds.amazonaws.com@3306@team29database
INSERT INTO Cart (user_id, product_id) VALUES
('ayoon', 1),
('ayoon', 2),
('joelm', 1);
