-- Active: 1708026071767@@team29-database.cobd8enwsupz.us-east-1.rds.amazonaws.com@3306@team29database
INSERT INTO Sponsor (SponsorName, SponsorPointRatio, IsActive) VALUES
('Walmart', 0.01, TRUE),
('Amazon', 0.01, TRUE),
('Costco', 0.01, TRUE);
