-- Active: 1708026071767@@team29-database.cobd8enwsupz.us-east-1.rds.amazonaws.com@3306@team29database
INSERT INTO AboutPage (team_number, version_number, release_date, product_name, product_description) VALUES
(29, '10.1', '2024-04-16', 'Good Driver Program', 'This product is designed to serve as an incentive program between Sponsor companies and their drivers!');
